# *****************************************************************************
# * Copyright © 2024 ams-OSRAM AG                                             *
# * All rights are reserved.                                                  *
# *                                                                           *
# * FOR FULL LICENSE TEXT SEE LICENSE.TXT                                     *
# *****************************************************************************

"""Wrapper of the Core FW C client, providing an API for communication with Core FW devices"""

import os
import typing
import corefw_c.defs
import corefw_c.evm_h5


class CoreFw:
    """Communicates with a Core FW device via USB CDC ACM."""

    def __init__(  # pylint: disable=dangerous-default-value
            self,
            interface: str,
            callback: typing.Callable[[int,
                                       int,
                                       typing.Optional[corefw_c.defs.Error],
                                       bytes],
                                      None] = ...,
            callback_message_ids: typing.Sequence[int] = []) -> None:
        """Creates an instance of the Core FW communication class.

        To establish a connection with the Core FW device, the connect method must be called explicitly.

        Via the callback, asynchronous messages received from the Core FW device can be transparently relayed to the
        user of this class for further processing. Only messages containing the user-specified command IDs or messages
        related to I3C IBIs, I3C errors, and PIO interrupts are delivered to the callback. The first argument of the
        callback is the value of the target field of the message. The second argument is the command ID of the received
        message. The third argument is a corefw_c.defs.Error exception object if the error code field contains a
        non-success code. In case of a value indicating success, the argument is None. The forth argument is the payload
        of the message. To parse the PIO interrupt messages, the first, second, and forth argument can be passed to the
        pio_extract_callback_data class method. The callback is called on every reception of an asynchronous message
        that is relayed. It is called from a thread other than the thread the constructor is called from. The Global
        Interpreter Lock (GIL) is acquired by the calling thread during each callback call. There is other essential
        activity occurring on the thread the callback is called from, so ensure that the callback function returns
        quickly as the thread is blocked while the callback function is executing. Do not assume that the implementation
        of any function of this class other than i3c_extract_ibi_callback_data, i3c_extract_err_callback_data, and
        pio_extract_callback_data are thread-safe.

        Args:
            interface: The interface string of the Core FW device to connect to (e.g. "COM:COM3", "COM:/dev/ttyACM0").
            callback: The callback for handling asynchronously received messages.
            callback_message_ids: The command IDs of asynchronously received messages which shall be relayed to the
                callback. The maximum number of command IDs is 8.
        """

    def connect(
            self) -> None:
        """Connects to the Core FW device.

        Raises:
            ConnectionError: If the device is already connected.
            corefw_c.defs.Error: On communication error.
        """

    def disconnect(
            self) -> None:
        """Disconnects from a Core FW device.

        Raises:
            ConnectionError: If the device is not connected.
            corefw_c.defs.Error: On communication error.
        """

    def transmit_packet(
            self,
            message_id: int,
            target: int,
            send_data: bytes) -> bytes:
        """
        Sends an arbitrary packet.

        Args:
            message_id: The command ID value to send.
            target: The target ID value to send.
            send_data: The input payload to send.

        Returns:
            The output payload received from the Core FW device.

        Raises:
            ConnectionError: If the device is not connected.
            corefw_c.defs.Error: If an error is indicated by the Core FW device or if a communication error has
                occurred.
        """

    def i2c_init(
            self,
            frequency: int,
            i2c_id: typing.Union[corefw_c.evm_h5.I2cId, int] = corefw_c.evm_h5.I2cId.MAIN) -> None:
        """Initializes an I2C interface.

        After calling this function, the corresponding I2C peripheral of the microcontroller is ready to be used and the
        associated pins are mapped to the I2C peripheral.

        This function must be called before calling any other I2C function.

        Args:
            frequency: The frequency of I2C interface in Hz.
            i2c_id: The ID of the I2C interface.

        Raises:
            ConnectionError: If the device is not connected.
            corefw_c.defs.Error: If an error is indicated by the Core FW device or if a communication error has
                occurred.
        """

    def i2c_transfer(
            self,
            addr: int,
            send_data: bytes,
            recv_len: int,
            i2c_id: typing.Union[corefw_c.evm_h5.I2cId, int] = corefw_c.evm_h5.I2cId.MAIN) -> bytes:
        """Performs an I2C transaction using an initialized I2C interface.

        This function can only called if the I2C interface has been initialized by an earlier call of the i2c_init
        method.

        Args:
            addr: The 7-bit address of the slave device.
            send_data: The data to send to the slave device.
            recv_len: The size of the data to read from the slave device.
            i2c_id: The ID of the I2C interface.

        Returns:
            The data read from the slave device.

        Raises:
            ConnectionError: If the device is not connected.
            corefw_c.defs.Error: If an error is indicated by the Core FW device or if a communication error has
                occurred.
        """

    def i2c_shutdown(
            self,
            i2c_id: typing.Union[corefw_c.evm_h5.I2cId, int] = corefw_c.evm_h5.I2cId.MAIN) -> None:
        """Closes an I2C interface.

        Args:
            i2c_id: The ID of the I2C interface.

        Raises:
            ConnectionError: If the device is not connected.
            corefw_c.defs.Error: If an error is indicated by the Core FW device or if a communication error has
                occurred.
        """

    def spi_init(
            self,
            frequency: int,
            mode: corefw_c.defs.SpiMode = corefw_c.defs.SpiMode.PHASE_1EDGE_POL_LOW,
            first_bit: corefw_c.defs.SpiFirstBit = corefw_c.defs.SpiFirstBit.MSB,
            spi_id: typing.Union[corefw_c.evm_h5.SpiId, int] = corefw_c.evm_h5.SpiId.MAIN) -> None:
        """Initializes an SPI interface.

        After calling this function, the corresponding SPI peripheral of the microcontroller is ready to be used and the
        associated pins are mapped to the SPI peripheral.

        This function must be called before calling any other SPI function.

        Args:
            frequency: The frequency of SPI interface in Hz.
            mode: The SPI mode the interface shall use.
            first_bit: The bit order the interface shall use.
            spi_id: The ID of the SPI interface.

        Raises:
            ConnectionError: If the device is not connected.
            corefw_c.defs.Error: If an error is indicated by the Core FW device or if a communication error has
                occurred.
        """

    def spi_transfer(
            self,
            send_data: bytes,
            recv_len: int,
            spi_id: typing.Union[corefw_c.evm_h5.SpiId, int] = corefw_c.evm_h5.SpiId.MAIN) -> bytes:
        """Performs an SPI transfer using an initialized SPI interface.

        This function can only called if the SPI interface has been initialized by an earlier call of the spi_init
        method.

        Args:
            send_data: The data to send on the MOSI line.
            recv_len: The number of bytes to read on the MISO line.
            spi_id: The ID of the SPI interface.

        Returns:
            The data read on the MISO line.

        Raises:
            ConnectionError: If the device is not connected.
            corefw_c.defs.Error: If an error is indicated by the Core FW device or if a communication error has
                occurred.
        """

    def spi_shutdown(
            self,
            spi_id: typing.Union[corefw_c.evm_h5.SpiId, int] = corefw_c.evm_h5.SpiId.MAIN) -> None:
        """Closes an SPI interface.

        Args:
            spi_id: The ID of the SPI interface.

        Raises:
            ConnectionError: If the device is not connected.
            corefw_c.defs.Error: If an error is indicated by the Core FW device or if a communication error has
                occurred.
        """

    def i3c_init(
            self,
            frequency: int,
            allow_i2c: bool = False,
            transfer_errors: bool = True,
            i3c_id: typing.Union[corefw_c.evm_h5.I3cId, int] = corefw_c.evm_h5.I3cId.MAIN) -> None:
        """Initializes an I3C interface.

        After calling this function, the corresponding I3C peripheral of the microcontroller is ready to be used and the
        associated pins are mapped to the I3C peripheral.

        This function must be called before calling any other I3C function.

        Args:
            frequency: The frequency of I3C interface in Hz.
            allow_i2c: If True, enable support for mixed I2C/I3C mode on the I3C interface.
            transfer_errors: If True, I3C errors that occurred on the I3C interface are communicated via asynchronous
                messages to the CoreFw instance.
            i3c_id: The ID of the I3C interface.

        Raises:
            ConnectionError: If the device is not connected.
            corefw_c.defs.Error: If an error is indicated by the Core FW device or if a communication error has
                occurred.
        """

    def i3c_assign_dynamic_addr(
            self,
            addrs: list[int],
            with_reset: bool = True,
            i3c_id: typing.Union[corefw_c.evm_h5.I3cId, int] = corefw_c.evm_h5.I3cId.MAIN) -> dict[int,
                                                                                                   typing.Tuple[int,
                                                                                                                int,
                                                                                                                int]]:
        """
        Assigns the provided I3C addresses to I3C slave devices connected to an initialized I3C interface.

        The function does not allow to assign a specific I3C address to a specific I3C slave device. Instead, the
        function assigns each slave device one of the provided I3C addresses in a non-deterministic way. If there are
        more I3C slave devices than provided I3C addresses, some I3C slave devices are not assigned an I3C address.

        This function can only called if the I3C interface has been initialized by an earlier call of the i3c_init
        method.

        Args:
            addrs: The I3C addresses to assign to the slave devices.
            with_reset: If True, RSTDAA is sent before ENTDAA is sent. Otherwise, only ENTDAA is sent.
            i3c_id: The ID of the I3C interface.

        Returns:
            A dictionary containing a key-value pair for every I3C address that has been assigned to a slave device. The
            key contains the assigned I3C address, while the value contains the DCR/BCR/PID triplet of the I3C slave
            device that has been assigned the I3C address. The DCR/BCR/PID triplets are provided as tuples where the
            first element contains the DCR value, the second element contains the BCR value, and the third element
            contains the PID value.

        Raises:
            ConnectionError: If the device is not connected.
            corefw_c.defs.Error: If an error is indicated by the Core FW device or if a communication error has
                occurred.
        """

    def i3c_enable_ibi(
            self,
            addrs: list[int],
            write_enec: bool = True,
            getbcr_override: typing.Tuple[bool, bool] = ...,
            i3c_id: typing.Union[corefw_c.evm_h5.I3cId, int] = corefw_c.evm_h5.I3cId.MAIN) -> None:
        """Enables the I3C IBI (In-Band Interrupt) handling of an initialized I3C interface.

        This function can only called if the I3C interface has been initialized by an earlier call of the i3c_init
        method.

        Args:
            addrs: The list of I3C addresses to enable IBI handling for. EVM-H5 supports up to four addresses.
            write_enec: If True, the ENEC CCC of all devices that IBI handling is being enabled for is written.
            getbcr_override: When this argument is passed, the GETBCR CCCs are not accessed. The first tuple element
                indicates whether all devices that IBI handling is being enabled for are IBI request capable, while the
                second element indicates whether IBIs of the devices have payloads.
            i3c_id: The ID of the I3C interface.

        Raises:
            ConnectionError: If the device is not connected.
            corefw_c.defs.Error: If an error is indicated by the Core FW device or if a communication error has
                occurred.
        """

    def i3c_disable_ibi(
            self,
            write_disec: bool = True,
            i3c_id: typing.Union[corefw_c.evm_h5.I3cId, int] = corefw_c.evm_h5.I3cId.MAIN) -> None:
        """Disables the I3C IBI (In-Band Interrupt) handling of an initialized I3C interface.

        This function can only called if the I3C interface has been initialized by an earlier call of the i3c_init
        method.

        Args:
            write_disec: If True, the DISEC CCC of all devices that IBI handling has been enabled for is written.
            i3c_id: The ID of the I3C interface.

        Raises:
            ConnectionError: If the device is not connected.
            corefw_c.defs.Error: If an error is indicated by the Core FW device or if a communication error has
                occurred.
        """

    def i3c_write_cccs(
            self,
            addr: int,
            cccs: dict[int, bytes],
            i3c_id: typing.Union[corefw_c.evm_h5.I3cId, int] = corefw_c.evm_h5.I3cId.MAIN) -> None:
        """Writes CCCs of an I3C slave device connected to an initialized I3C interface.

        This function can only called if the I3C interface has been initialized by an earlier call of the i3c_init
        method.

        Args:
            addr: The I3C address of the slave devices.
            cccs: A dictionary containing a key-value pair for every CCC to write. The key contains the CCC ID, while
                the value contains the CCC payload to write.
            i3c_id: The ID of the I3C interface.

        Raises:
            ConnectionError: If the device is not connected.
            corefw_c.defs.Error: If an error is indicated by the Core FW device or if a communication error has
                occurred.
        """

    def i3c_read_cccs(
            self,
            addr: int,
            cccs: dict[int, int],
            i3c_id: typing.Union[corefw_c.evm_h5.I3cId, int] = corefw_c.evm_h5.I3cId.MAIN) -> dict[int, bytes]:
        """Reads CCCs of an I3C slave device connected to an initialized I3C interface.

        This function can only called if the I3C interface has been initialized by an earlier call of the i3c_init
        method.

        Args:
            addr: The I3C address of the slave devices.
            cccs: A dictionary containing a key-value pair for every CCC to read. The key contains the CCC ID, while
                the value contains the size of the CCC payload to read.
            i3c_id: The ID of the I3C interface.

        Returns:
            A dictionary containing a key-value pair for every CCC that has been read. The key contains the CCC ID,
            while the value contains the read CCC payload.

        Raises:
            ConnectionError: If the device is not connected.
            corefw_c.defs.Error: If an error is indicated by the Core FW device or if a communication error has
                occurred.
        """

    def i3c_transfer(
            self,
            addr: int,
            send_data: bytes,
            recv_len: int,
            i2c_mode: bool = False,
            i3c_id: typing.Union[corefw_c.evm_h5.I3cId, int] = corefw_c.evm_h5.I3cId.MAIN) -> bytes:
        """Performs an I3C transaction using an initialized I3C interface.

        This function can only called if the I3C interface has been initialized by an earlier call of the i2c_init
        method.

        Args:
            addr: The 7-bit address of the slave device.
            send_data: The data to send to the slave device.
            recv_len: The size of the data to read from the slave device.
            i2c_mode: If True, the transaction is performed in I2C mode.
            i3c_id: The ID of the I3C interface.

        Returns:
            The data read from the slave device.

        Raises:
            ConnectionError: If the device is not connected.
            corefw_c.defs.Error: If an error is indicated by the Core FW device or if a communication error has
                occurred.
        """

    def i3c_shutdown(
            self,
            i3c_id: typing.Union[corefw_c.evm_h5.I3cId, int] = corefw_c.evm_h5.I3cId.MAIN) -> None:
        """Closes an I3C interface.

        Args:
            i3c_id: The ID of the I3C interface.

        Raises:
            ConnectionError: If the device is not connected.
            corefw_c.defs.Error: If an error is indicated by the Core FW device or if a communication error has
                occurred.
        """

    def i3c_extract_ibi_callback_data(
            self,
            target: int,
            msg_id: int,
            data: bytes) -> typing.Optional[typing.Tuple[typing.Union[corefw_c.evm_h5.I3cId, int], int, bytes]]:
        """Checks whether a received asynchronous message is related to I3C IBIs and parses it if so.

        This function is supposed to be called from the callback registered during the initialization of an instance of
        this class. It is a convenience function to extract the I3C interface ID, the I3C slave device address, and the
        IBI payload from the received message. When the function returns a non-None value, the message is related to I3C
        IBIs and the data has been extracted.

        The function can safely be called from the thread the callback function is called from.

        Args:
            target: The value of the target field of the received message.
            msg_id: The value of the command ID field of the received message.
            data: The payload data of the received message.

        Returns:
            A tuple with three elements if the message is related to I3C IBIs. The first element contains the ID of
            the I3C interface. The second element contains the I3C address of the slave device that generated the IBI.
            The third element contains the payload data of the IBI. of the pin. If the message is not related to I3C
            IBIs, None is returned.

        Raises:
            ConnectionError: If the device is not connected.
        """

    def i3c_extract_err_callback_data(
            self,
            target: int,
            msg_id: int,
            data: bytes) -> typing.Optional[typing.Tuple[typing.Union[corefw_c.evm_h5.I3cId, int],
                                                         corefw_c.defs.I3cError]]:
        """Checks whether a received asynchronous message is related to I3C errors and parses it if so.

        This function is supposed to be called from the callback registered during the initialization of an instance of
        this class. It is a convenience function to extract the I3C interface ID and the I3C error from the received
        message. When the function returns a non-None value, the message is related to I3C errors and the data has been
        extracted.

        The function can safely be called from the thread the callback function is called from.

        Args:
            target: The value of the target field of the received message.
            msg_id: The value of the command ID field of the received message.
            data: The payload data of the received message.

        Returns:
            A tuple with two elements if the message is related to I3C errors. The first element contains the ID of
            the I3C interface. The second element contains the I3C error that has occurred. If the message is not
            related to I3C errors, None is returned.

        Raises:
            ConnectionError: If the device is not connected.
        """

    def pio_init(
            self,
            pio_id: typing.Union[corefw_c.evm_h5.PioId, int],
            mode: typing.Union[corefw_c.defs.PioMode, int],
            pull: typing.Union[corefw_c.defs.PioPull, int] = corefw_c.defs.PioPull.NONE) -> None:
        """Initializes a PIO pin.

        This function must be called before calling any other PIO function.

        Args:
            pio_id: The ID of the pin.
            mode: The mode the pin shall be set to.
            pull: The pull up/down resistor configuration the pin shall be set to.

        Raises:
            ConnectionError: If the device is not connected.
            corefw_c.defs.Error: If an error is indicated by the Core FW device or if a communication error has
                occurred.
        """

    def pio_set(
            self,
            pio_id: typing.Union[corefw_c.evm_h5.PioId, int],
            state: typing.Union[corefw_c.defs.PioState, int]) -> None:
        """Sets the state of a PIO pin that has been configured as an output.

        Args:
            pio_id: The ID of the pin.
            state: The state the pin shall be set to.

        Raises:
            ConnectionError: If the device is not connected.
            corefw_c.defs.Error: If an error is indicated by the Core FW device or if a communication error has
                occurred.
        """

    def pio_get(
            self,
            pio_id: typing.Union[corefw_c.evm_h5.PioId, int]) -> corefw_c.defs.PioState:
        """Gets the state of a PIO pin.

        Args:
            pio_id: The ID of the pin.

        Returns:
            The current state the pin.

        Raises:
            ConnectionError: If the device is not connected.
            corefw_c.defs.Error: If an error is indicated by the Core FW device or if a communication error has
                occurred.
        """

    def pio_shutdown(
            self,
            pio_id: typing.Union[corefw_c.evm_h5.PioId, int]) -> None:
        """Closes a PIO pin.

        Args:
            pio_id: The ID of the pin.

        Raises:
            ConnectionError: If the device is not connected.
            corefw_c.defs.Error: If an error is indicated by the Core FW device or if a communication error has
                occurred.
        """

    def pio_extract_callback_data(
            self,
            target: int,
            msg_id: int,
            data: bytes) -> typing.Optional[typing.Tuple[typing.Union[corefw_c.evm_h5.PioId, int],
                                                         corefw_c.defs.PioState]]:
        """Checks whether a received asynchronous message is related to PIO interrupts and parses it if so.

        This function is supposed to be called from the callback registered during the initialization of an instance of
        this class. It is a convenience function to extract pin ID and pin state from the received message. When the
        function returns a non-None value, the message is related to PIO interrupts and the data has been extracted.

        The function can safely be called from the thread the callback function is called from.

        Args:
            target: The value of the target field of the received message.
            msg_id: The value of the command ID field of the received message.
            data: The payload data of the received message.

        Returns:
            A tuple with two elements if the message is related to PIO interrupts. The first element contains the ID of
            the pin. The second element contains the state of the pin. If the message is not related to PIO interrupts,
            None is returned.

        Raises:
            ConnectionError: If the device is not connected.
        """

    def pwm_init(
            self,
            pwm_id: typing.Union[corefw_c.evm_h5.PwmId, int],
            frequency: int,
            duty_cycle: float) -> None:
        """Initializes a PWM output.

        Args:
            pwm_id: The ID of the PWM output.
            frequency: The frequency of the waveform in Hz.
            duty_cycle: The duty cycle of the waveform. A value of 0.0 represents a duty cycle of 0% while a value of
                1.0 represents a duty cycle of 100%.

        Raises:
            ConnectionError: If the device is not connected or if the duty cycle value is invalid.
            corefw_c.defs.Error: If an error is indicated by the Core FW device or if a communication error has
                occurred.
        """

    def pwm_shutdown(
            self,
            pwm_id: typing.Union[corefw_c.evm_h5.PwmId, int]) -> None:
        """Closes a PWM output pin.

        Args:
            pwm_id: The ID of the PWM output.

        Raises:
            ConnectionError: If the device is not connected.
            corefw_c.defs.Error: If an error is indicated by the Core FW device or if a communication error has
                occurred.
        """

    def sff_init(
            self,
            dev_addr: int,
            fifo_reg: int,
            fifo_level_reg_addrs: list[int],
            fifo_level_reg_shifts: list[int],
            fifo_level_reg_masks: list[int],
            fifo_threshold: int,
            max_fifo_size: int,
            chunk_size: int,
            status_reg_addr: int = 0,
            num_status_regs: int = 0,
            use_int_pin: bool = False,
            is_int_high_active: bool = False,
            int_pio_id: typing.Union[corefw_c.evm_h5.PioId, int] = 0,
            i2c_id: typing.Union[corefw_c.evm_h5.I2cId, int] = corefw_c.evm_h5.I2cId.MAIN) -> None:
        """Initializes the smart FIFO module for the given I2C interface.

        After calling this function, the corresponding I2C peripheral reads cyclic data from the slave's FIFO and
        transmits it asynchronously.

        Calculation of the internal fifo level:

            fifo_level = ((data_of_fifo_level_reg_addrs[0] & fifo_level_reg_masks[0]) << fifo_level_reg_shifts[0]) |
                        ((data_of_fifo_level_reg_addrs[1] & fifo_level_reg_masks[1]) << fifo_level_reg_shifts[1])

        Args:
            dev_addr: Device address of the slave.
            fifo_reg: Definition of the FIFO register address.
            fifo_level_reg_addrs: 2 bytes for both fifo level register addresses.
            fifo_level_reg_shifts: 2 bytes to define the shifting of fifo level registers.
            fifo_level_reg_masks: 2 bytes bit-masking of fifo level register content.
            fifo_threshold: Configured FIFO threshold inside the IC.
            max_fifo_size: Maximum supported FIFO size.
            chunk_size: Smallest block size of every FIFO read.
            status_reg_addr: Start address for additional status register read.
            num_status_regs: Number of status register which shall be read.
            use_int_pin: Use interrupt pin.
            is_int_high_active: Is interrupt high-active.
            int_pio_id: ID of the interrupt port.
            i2c_id: The ID of the I2C interface.

        Raises:
            ConnectionError: If the device is not connected.
            corefw_c.defs.Error: If an error is indicated by the Core FW device or if a communication error has
                occurred.
        """

    def sff_shutdown(
            self,
            i2c_id: typing.Union[corefw_c.evm_h5.I2cId, int] = corefw_c.evm_h5.I2cId.MAIN) -> None:
        """Closes a smart FIFO interface.

        Args:
            i2c_id: The ID of the I2C interface.

        Raises:
            ConnectionError: If the device is not connected.
            corefw_c.defs.Error: If an error is indicated by the Core FW device or if a communication error has
                occurred.
        """

    def sff_extract_callback_data(
            self,
            target: int,
            msg_id: int,
            data: bytes,
            error: int = 0) -> typing.Optional[typing.Tuple[bytes, int, bytes, bytes, typing.Union[corefw_c.evm_h5.I3cId, int]]]:
        """Checks whether a received asynchronous message is related to smart FIFO data and parses it if so.

        This function is supposed to be called from the callback registered during the initialization of an instance of
        this class. It is a convenience function to extract the data of the cyclic smart FIFO data.
        When the function returns a non-None value, the message is related to smart FIFO
        and the data has been extracted.

        The function can safely be called from the thread the callback function is called from.

        Args:
            target: The value of the target field of the received message.
            msg_id: The value of the command ID field of the received message.
            data: The payload data of the received message.
            error: [Optional] Possible error code of the async message.

        Returns:
            A tuple with five elements if the message is related to smart FIFO. The first element contains 2 bytes
            of the FIFO level register. The second element contains a running counter which counts till 255 and wraps
            around afterwards. The third element contains the read status register data.
            The fourth element contains the read FIFO data. The fifth element describes the used I2C interface.
            If the message is not related to smart FIFO, None is returned.

        Raises:
            TypeError: Parameter type is wrong.
            OverflowError: Data size it too big.
            corefw_c.defs.Error: If an error is indicated by the Core FW device or if a communication error has
                occurred.
        """

    def update_firmware(
            self,
            dfu_file: typing.Union[str, bytes, os.PathLike],
            timeout_ms: int = 4000,
            callback: typing.Callable[[str, int], None] = ...) -> None:
        """Updates the firmware of the device.

        When the callback argument is passed, the callback is invoked several times during the firmware update to
        provide information about the progress of the firmware update. The first argument of the callback is a string
        describing the current stage of the update process. The second argument is an integer value containing the
        progress within the current stage as a percentage. The callback is called from the same thread this method is
        called from.

        Arguments:
            dfu_file: The path of the DFU file to use.
            timeout_ms: The maximum time (in milliseconds) spent waiting for the device to be found in DFU mode.
            callback: The callback for progress updates.

        Raises:
            ConnectionError: If the device is not connected.
            corefw_c.defs.Error: If an error is indicated by the Core FW device, if a communication error has
                occurred, or if the firmware update has failed.
        """

    def enter_bootloader(
            self,
            timeout_ms: int = 4000) -> str:
        """Causes a device to enter DFU mode without initiating a firmware update.

        Arguments:
            timeout_ms: The maximum time (in milliseconds) spent waiting for the device to be found in DFU mode.

        Returns:
            The serial number of the device that has entered DFU mode.

        Raises:
            ConnectionError: If the device is not connected.
            corefw_c.defs.Error: If an error is indicated by the Core FW device, if a communication error has
                occurred, or if the bootloader start has failed.
        """

    @classmethod
    def update_firmware_in_bootloader(
            cls,
            dfu_file: typing.Union[str, bytes, os.PathLike],
            serial_number: str = ...,
            timeout_ms: int = 4000,
            callback: typing.Callable[[str, int], None] = ...) -> None:
        """Updates the firmware of a device that is already in DFU mode.

        When the callback argument is passed, the callback is invoked several times during the firmware update to
        provide information about the progress of the firmware update. The first argument of the callback is a string
        describing the current stage of the update process. The second argument is an integer value containing the
        progress within the current stage as a percentage. The callback is called from the same thread this method is
        called from.

        Arguments:
            dfu_file: The path of the DFU file to use.
            serial_number: The serial number of the device to update. When this argument is not passed, the first device
                found in DFU mode is updated.
            timeout_ms: The maximum time (in milliseconds) spent waiting for the device to be found.
            callback: The callback for progress updates.

        Raises:
            corefw_c.defs.Error: If a communication error has occurred or if the firmware update has failed.
        """

    @classmethod
    def leave_bootloader(
            cls,
            serial_number: str = ...,
            timeout_ms: int = 4000) -> None:
        """Causes a device to leave DFU mode.

        Arguments:
            serial_number: The serial number of the device to update. When this argument is not passed, the first device
                found in DFU mode is updated.
            timeout_ms: The maximum time (in milliseconds) spent waiting for the device to be found.

        Raises:
            corefw_c.defs.Error: If a communication error has occurred or if the firmware update has failed.
        """

    @classmethod
    def list_devices(  # pylint: disable=too-many-arguments
            cls,
            name: str = ...,
            serial_number: str = ...,
            interface: str = ...,
            vid: int = ...,
            pid: int = ...) -> list[corefw_c.defs.DeviceInfo]:
        """Lists all available USB CDC ACM devices that fulfill all specified filter criteria.

        All arguments of this function are optional. To disable a filter, do not pass the corresponding argument.

        Args:
            name: The device name filter value. When this argument is passed, only devices whose names exactly match
                this string are returned.
            serial_number: The serial number filter value. When this argument is passed, only devices whose serial
                numbers exactly match this string are returned.
            interface: The interface string filter value. When this argument is passed, only devices whose interface
                strings(e.g. `COM: COM3`, `COM:/dev/ttyACM0`) exactly match this string are returned.
            vid: The USB Vendor ID filter value. When this argument is passed, only devices whose USB Vendor IDs match
                this ID are returned.
            pid: The USB Product ID filter value. When this argument is passed, only devices whose USB Product IDs match
                this ID are returned. The USB Product ID filter can only be used in combination with the USB Vendor ID
                filter.

        Returns:
            A list containing information about all devices that fulfill all specified filter criteria.
        """

    @property
    def firmware_info(
            self) -> corefw_c.defs.FirmwareInfo:
        """
        Information about the firmware running on the connected Core FW device.

        Raises:
            ConnectionError: If the device is not connected.
        """

    @property
    def i2c_ids(
            self) -> typing.Union[typing.Type[corefw_c.evm_h5.I2cId], typing.Type[int]]:
        """
        The preferred type to use to represent I2C interface IDs of the connected Core FW device.

        Raises:
            ConnectionError: If the device is not connected.
        """

    @property
    def spi_ids(
            self) -> typing.Union[typing.Type[corefw_c.evm_h5.SpiId], typing.Type[int]]:
        """
        The preferred type to use to represent SPI interface IDs of the connected Core FW device.

        Raises:
            ConnectionError: If the device is not connected.
        """

    @property
    def i3c_ids(
            self) -> typing.Union[typing.Type[corefw_c.evm_h5.I3cId], typing.Type[int]]:
        """
        The preferred type to use to represent I3C interface IDs of the connected Core FW device.

        Raises:
            ConnectionError: If the device is not connected.
        """

    @property
    def pio_ids(
            self) -> typing.Union[typing.Type[corefw_c.evm_h5.PioId], typing.Type[int]]:
        """
        The preferred type to use to represent PIO pin IDs of the connected Core FW device.

        Raises:
            ConnectionError: If the device is not connected.
        """

    @property
    def pwm_ids(
            self) -> typing.Union[typing.Type[corefw_c.evm_h5.PwmId], typing.Type[int]]:
        """
        The preferred type to use to represent PWM output IDs of the connected Core FW device.

        Raises:
            ConnectionError: If the device is not connected.
        """
